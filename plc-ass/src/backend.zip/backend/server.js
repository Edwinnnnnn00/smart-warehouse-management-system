import express from 'express'
import cors from 'cors'

const app = express()
app.use(express.json())
app.use(cors({
    origin: 'http://localhost:5173' // Allow requests from this origin only
}));

let status = {
    light1: false,      //true: object detected
    light2: false,      //false: no object detected
    light3: false,
    light4: false,
    light5: false,
    medium1: false,
    medium2: false,
    medium3: false,
    medium4: false,
    medium5: false,
    heavy1: false,
    heavy2: false,
    heavy3: false,
    heavy4: false,
    heavy5: false,
    temp: 30,
    alarm: false,
    power: false,
}

app.use((err, req, res, next) => {
    console.error(err.stack)
    res.status(500).send('Something broke!')
})

app.get('/', (req, res) => {
    console.log('Getting request /')
    // res.send(status);
    setTimeout(() => {
        res.send(status)
    }, 2000)
});

app.listen(8080, () => {
    console.log('Listening on port 8080')
})